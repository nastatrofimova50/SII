import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.applications.efficientnet import preprocess_input
import matplotlib.pyplot as plt
import os

model = load_model("apple-tomato_model.keras", custom_objects={'preprocess_input': preprocess_input})

test_data_dir = "C://Users/Nastya/Desktop/sii/lab1/dataset6/validate"
test_dataset = tf.keras.preprocessing.image_dataset_from_directory(
    test_data_dir,
    image_size=(256, 256),
    batch_size=1,
    shuffle=False
)

class_names = test_dataset.class_names
print("Классы:", class_names)

file_paths = []
for root, dirs, files in os.walk(test_data_dir):
    for file in sorted(files):
        if file.lower().endswith(('jpg', 'jpeg', 'png')):
            file_paths.append(os.path.join(root, file))

for i, (images, labels) in enumerate(test_dataset):
    predictions = model.predict(images, verbose=0)
    prob = float(predictions[0][0])
    predicted_class = class_names[int(prob > 0.5)]
    file_name = os.path.basename(file_paths[i])

    plt.figure(figsize=(4, 4))
    plt.imshow(images[0].numpy().astype("uint8"))
    plt.title(f"{file_name}\n{predicted_class} ({prob:.2%})", fontsize=10)
    plt.axis('off')
    plt.tight_layout()
    plt.show()